﻿using PriceBey.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace PriceBey.Controllers
{
    public class TermsController : Controller
    {

        public ActionResult Index()
        {
            return View();
        }
    }
}
  